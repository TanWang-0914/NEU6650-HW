# Purchase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;PurchaseItems&gt;**](PurchaseItems.md) |  |  [optional]
